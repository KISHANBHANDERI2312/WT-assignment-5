<?php
define("DB_HOST", "localhost");
define("DB_NAME", "new_db");
define("DB_USER", "new_db_username");
define("DB_PASS", "24\0$(o@VNjqaGJ4");

define("TAB_ASS5", "wtass5");
?>